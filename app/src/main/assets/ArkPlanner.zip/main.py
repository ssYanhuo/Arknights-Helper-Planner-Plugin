import sys, codecs, json
from MaterialPlanning import *

#Created by ycremar
#Modified by ssYanhuo


def plan(required_json, owned_json):
    if '-fe' in sys.argv:
        filter_stages = ['GT-'+str(i) for i in range(1,7)]
    else:
        filter_stages = []
    
    mp = MaterialPlanning(filter_stages=filter_stages)
#    with codecs.open('/data/data/com.ssyanhuo.pythontest/files/required.txt', 'r', 'utf-8') as f:
#        required_dct = {}
#        for line in f.readlines():
#            required_dct[line.split(' ')[0]] = int(line.split(' ')[1])
#            
#    with codecs.open('/data/data/com.ssyanhuo.pythontest/files/owned.txt', 'r', 'utf-8') as f:
#        owned_dct = {}
#        for line in f.readlines():
#            owned_dct [line.split(' ')[0]] = int(line.split(' ')[1])
    result = mp.get_plan(json.loads(required_json), json.loads(owned_json), True, outcome=True, gold_demand=False, exp_demand=True)
    return result;
